<?php

//IP de la pc servidor de base de datos
define("DB_HOST", "localhost");

//Nombre de la base de datos
define("DB_NAME", "valentina");

//Usuario de la base de datos
define("DB_USERNAME", "root");

//Contrase���a de la base de datos
define("DB_PASSWORD", "");

//Codificacion de caracteres
define("DB_ENCODE", "uft8");

//Nombre del proyecto
define("PRO_NOMBRE", "AdminWebPage");